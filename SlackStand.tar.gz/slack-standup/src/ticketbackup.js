const axios = require('axios');
const debug = require('debug')('slash-command-template:ticket');
const qs = require('querystring');
const users = require('./users');
const deasync = require("deasync");
const {table} = require('table');
const cTable = require('console.table');

/*
 *  Send ticket creation confirmation via
 *  chat.postMessage to the user who created it
 */
const sendConfirmation = (ticket,chan_id) => {
  console.log(ticket.userId,"insidesend")
  axios.post('https://slack.com/api/chat.postMessage', qs.stringify({
    token: process.env.SLACK_ACCESS_TOKEN,
    channel: ticket.userId,
    as_user: true,
    text: 'Standup Meeting!',
    attachments: JSON.stringify([
      {
        title: `Standup report by ${ticket.userEmail}`,
        // Get this from the 3rd party helpdesk system
        title_link: 'http://example.com',
        text: ticket.text,
        fields: [
          {
            title: 'Question-1',
            value: ticket.question1,
            short: true,
          },
          {
            title: 'Question-2',
            value: ticket.question2,
            short: true,
          },
          {
            title: 'Blockers',
            value: ticket.blockers || 'None provided',
            short: true,
          },
          {
            title: 'Status',
            value: 'Open',
            short: true,
          },
          {
            title: 'Urgency',
            value: ticket.urgency,
            short: true,
          },
        ],
      },
    ]),
  })).then((result) => {
    debug('sendConfirmation: %o', result.data);
    //console.log(result)

    /*axios.post('https://slack.com/api/chat.postMessage', qs.stringify({
      token: process.env.SLACK_ACCESS_TOKEN,
      channel: chan_id,
      as_user: false,
      username:"Standup",
      text: 'Standup Meeting!',
      ts:result.data.ts,
      reply_broadcast:true
    })).then((result) => {
      debug('sendConfirmation: %o', result.data);
      console.log(result.data)
    }).catch((err) => {
      debug('sendConfirmation error: %o', err);
      console.error(err);
    });*/
  }).catch((err) => {
    debug('sendConfirmation error: %o', err);
    console.error(err);
  });


  
};

const sendConfirmationreport = (ticket,chan) => {
  console.log(ticket);
  tab = []
  tab.push(["UserName","Question1","Question2","Blockers"])
  for(x of ticket)
  {
    tab.push([`@` + x.user_identity,x.Question1,x.Question2,x.Blockers])
  }
  //console.log(table(tab))
  textinit = table(tab);
  console.log(String(textinit));
  axios.post('https://slack.com/api/chat.postMessage', qs.stringify({
    token: process.env.SLACK_ACCESS_TOKEN,
    channel: chan,
    as_user: false,
    username:"Standup Report",
    text: "Report",
    attachments: JSON.stringify([
      {
        title: `Summary`,
        // Get this from the 3rd party helpdesk system
        title_link: 'http://example.com',
        text: textinit,
      }])
  })).then((result) => {
    debug('sendConfirmation: %o', result.data);
    console.log(result)


  }).catch((err) => {
    debug('sendConfirmation error: %o', err);
    console.error(err);
  });

  
};

// Create helpdesk ticket. Call users.find to get the user's email address
// from their user ID
const create = (userId, submission,li,chan_id) => {
  const ticket = {};

  const fetchUserEmail = new Promise((resolve, reject) => {
    users.find(userId).then((result) => {
      debug(`Find user: ${userId}`);
      resolve(result.data.user.profile.email);
    }).catch((err) => { reject(err); });
  });

  console.log(li,"ids")

 

    fetchUserEmail.then((result) => {
      for(ids of li){
          console.log(ids)
          const ticket = {};
          ticket.userId = ids;
          ticket.userEmail = result;
          ticket.question1 = submission.question1;
          ticket.question2 = submission.question2;
          ticket.blockers = submission.blockers;
          ticket.urgency = submission.urgency;
          sendConfirmation(ticket,chan_id);
      }
    return ticket;
  }).catch((err) => { console.error(err); });
    



}
module.exports = { create, sendConfirmation,sendConfirmationreport };
