const axios = require('axios');
const debug = require('debug')('slash-command-template:ticket');
const qs = require('querystring');
const users = require('./users');
var MongoClient = require('mongodb').MongoClient;
const deasync = require("deasync");
const {table,getBorderCharacters} = require('table');
const cTable = require('console.table');
const token = process.env.SLACK_ACCESS_TOKEN
let Slack = require('slack')
let bot = new Slack({token})
Tablenew = require('cli-table')
const PDFDocument = require('pdfkit');
var fs = require("fs");
const {Table} = require('console-table-printer');
const p = new Table();
var url = "mongodb://localhost:27017/";

/*
 *  Send ticket creation confirmation via
 *  chat.postMessage to the user who created it
 */
const sendConfirmation = (ticket,chan_id) => {
  console.log(ticket.userId,"insidesend")
  axios.post('https://slack.com/api/chat.postMessage', qs.stringify({
    token: process.env.SLACK_ACCESS_TOKEN,
    channel: ticket.userId,
    as_user: true,
    text: 'Standup Meeting!',
    attachments: JSON.stringify([
      {
        title: `Standup report by ${ticket.userEmail}`,
        // Get this from the 3rd party helpdesk system
        title_link: 'http://example.com',
        text: ticket.text,
        fields: [
          {
            title: 'Question-1',
            value: ticket.question1,
            short: true,
          },
          {
            title: 'Question-2',
            value: ticket.question2,
            short: true,
          },
          {
            title: 'Blockers',
            value: ticket.blockers || 'None provided',
            short: true,
          },
          {
            title: 'Status',
            value: 'Open',
            short: true,
          },
          {
            title: 'Urgency',
            value: ticket.urgency,
            short: true,
          },
        ],
      },
    ]),
  })).then((result) => {
    debug('sendConfirmation: %o', result.data);
    //console.log(result)

    /*axios.post('https://slack.com/api/chat.postMessage', qs.stringify({
      token: process.env.SLACK_ACCESS_TOKEN,
      channel: chan_id,
      as_user: false,
      username:"Standup",
      text: 'Standup Meeting!',
      ts:result.data.ts,
      reply_broadcast:true
    })).then((result) => {
      debug('sendConfirmation: %o', result.data);
      console.log(result.data)
    }).catch((err) => {
      debug('sendConfirmation error: %o', err);
      console.error(err);
    });*/
  }).catch((err) => {
    debug('sendConfirmation error: %o', err);
    console.error(err);
  });


  
};

const sendConfirmationreport = (ticket,chan,sendinit) => {
  console.log(ticket);
  report_string = ``;
  blockerofday = `\n`+'```';

  //tabula = []
  //tab = []
  //tab.push(["UserName","Question-1","Question-2","Blockers"])
  for(x of ticket)
  {
    //tab.push([`<@` + x.user_identity +`>`,x.Question1,x.Question2,x.Blockers])
    //tabula.push([`<@` + x.user_identity+`>`,x.Question1,x.Question2,x.Blockers])
    //p.addRow({ "UserName": `<@` + x.user_identity+`>`, "Question-1": x.Question1,"Question-2": x.Question2, "Blockers": x.Blockers});
  
   report_string =  report_string+''+ `>\`<@` + x.user_identity +`>\`\n` + `*`+`What did you do yesterday?`+`*\n` + x.Question1 +
                    `\n*`+`What did you do today?`+`*\n`+ x.Question2 + `\n*`+`Blockers?`+`*\n` + x.Blockers +`\n`;
    

  if(String(x.Blockers).toUpperCase() != "NONE" && String(x.Blockers).toUpperCase() != "NOTHING")
  {
    blockerofday = blockerofday + x.Blockers +`\n`;
  }
   
  }

  report_string = report_string ;
  blockerofday = blockerofday + '```';
  /*configtab = {
    border: getBorderCharacters(`void`),
    columns: {
      0: {
        alignment: 'left',
        width: 20,
        wrapWord: true
        
      },
      1: {
        alignment: 'left',
        width: 20,
        wrapWord: true
      },
      2: {
        alignment: 'left',
        width: 20,
        wrapWord: true
      },
      3: {
        alignment: 'left',
        width: 20,
        wrapWord: true
      }
    }
  };


  var chars = {
    'top': '═', 'top-mid': '╤', 'top-left': '╔', 'top-right': '╗',
    'bottom': '═', 'bottom-mid': '╧', 'bottom-left': '╚',
    'bottom-right': '╝', 'left': '║', 'left-mid': '╟', 'mid': '─',
    'mid-mid': '┼', 'right': '║', 'right-mid': '╢', 'middle': '│'
  };

  headers = ["UserName","Question-1","Question-2","Blockers"];
  values = tabula;
  aligns = ['left', 'left', 'left', 'left'];

  tablehtr = new Tablenew({ head: headers, chars: chars, colAligns: aligns })

  tablehtr.push.apply(tablehtr, values);
  console.log(tablehtr.toString());*/

  //table = new Table({ head: headers, chars: chars, colAligns: aligns })

  //console.log(cTable.getTable(tab))

  //p.printTable();


  //textinit = table(tab,configtab);
  //console.log(String(textinit));

  /*channel = chan;
  text = textinit;
  ;(async function main() {
    // logs {args:{hyper:'card'}}
    var resultofs = await Slack.chat.postMessage({token, channel, text})
    console.log(resultofs)
  })()*/

  /*axios.post('https://slack.com/api/chat.postMessage', qs.stringify({
    token: process.env.SLACK_ACCESS_TOKEN,
    channel: chan,
    as_user: false,
    username:"Standup Report",
    text: `*`+`Standup Report  - `+`String(today).split(" ").slice(1,4).toString()`+`\*n`+ String(report_string) +`\n`,
    attachments: JSON.stringify([
      {
        text:  String(blockerofday),
      }])
  })).then((result) => {
    debug('sendConfirmation: %o', result.data);
    //console.log(result)
  }).catch((err) => {
    debug('sendConfirmation error: %o', err);
    console.error(err);
  });*/

  var today=new Date();
  var dateformt = String(today).split(" ");

  axios.post('https://slack.com/api/chat.postMessage', qs.stringify({
    token: process.env.SLACK_ACCESS_TOKEN,
    channel: chan,
    as_user: false,
    username:``+`Standup Report  - `+String(dateformt.slice(2,3))+" " + String(dateformt.slice(1,2)) +" "+ String(dateformt.slice(3,4))+``,
    text:  String(report_string) +`\n`,
  })).then((result) => {
    debug('sendConfirmation: %o', result.data);
    //console.log(result)
  }).catch((err) => {
    debug('sendConfirmation error: %o', err);
    console.error(err);
  });

  axios.post('https://slack.com/api/chat.postMessage', qs.stringify({
    token: process.env.SLACK_ACCESS_TOKEN,
    channel: sendinit,
    as_user: true,
    text: `*`+`Blockers for the day!  - `+String(dateformt.slice(2,3))+" " + String(dateformt.slice(1,2)) +" "+ String(dateformt.slice(3,4))+`\n`+String(blockerofday),
  })).then((result) => {
    debug('sendConfirmation: %o', result.data);
    //console.log(result)
  }).catch((err) => {
    debug('sendConfirmation error: %o', err);
    console.error(err);
  });

  setTimeout(() => {
  MongoClient.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    dbo.collection(String(chan) + String(sendinit)).drop(function(err, delOK) {
      if (err) throw err;
      if (delOK) console.log("Collection deleted");
      db.close();
    });
  })},1000*10)

  //const doc = new PDFDocument();

  //doc.pipe(fs.createWriteStream('report.pdf'));

  //doc.fontSize(10)
   //.text(String(String(textinit)), 100, 100)

  // doc.end();
};

// Create helpdesk ticket. Call users.find to get the user's email address
// from their user ID
const create = (userId, submission,li,chan_id) => {
  const ticket = {};

  const fetchUserEmail = new Promise((resolve, reject) => {
    users.find(userId).then((result) => {
      debug(`Find user: ${userId}`);
      resolve(result.data.user.profile.email);
    }).catch((err) => { reject(err); });
  });

  console.log(li,"ids")

 

    fetchUserEmail.then((result) => {
      for(ids of li){
          console.log(ids)
          const ticket = {};
          ticket.userId = ids;
          ticket.userEmail = result;
          ticket.question1 = submission.question1;
          ticket.question2 = submission.question2;
          ticket.blockers = submission.blockers;
          ticket.urgency = submission.urgency;
          sendConfirmation(ticket,chan_id);
      }
    return ticket;
  }).catch((err) => { console.error(err); });
    



}
module.exports = { create, sendConfirmation,sendConfirmationreport };
